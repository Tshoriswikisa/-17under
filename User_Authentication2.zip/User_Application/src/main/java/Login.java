/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * 
 * 
  * @author Swiki
 */
import java.util.Scanner;

public class Login {
    private final String userName;
    private final String password;

public Login(String userName, String password) {
this.userName = userName;
this.password = password;
}

public String getUserName() {
return this.userName;
}

public String getPassword() {
return this.password;
}

public boolean validate() {
return (this.userName).equals("Swiki") && (this.password).equals("123abc@A")
        && (this.password.length() >= 8) && (this.password.length() <= 10)
        && (!(this.password.contains(" "))) && ((this.password.contains("@")|| this.password.contains("#")
        || this.password.contains("!") || this.password.contains("~")
        || this.password.contains("$") || password.contains("%")
        || this.password.contains("^") || this.password.contains("&")
        || this.password.contains("*") || this.password.contains("(")
        || this.password.contains(")") || this.password.contains("-")
        || this.password.contains("+") || this.password.contains("/")
        || this.password.contains(":") || this.password.contains(".")
        || this.password.contains(", ") || this.password.contains("<")
        || this.password.contains(">") || this.password.contains("?")
        || this.password.contains("|")));
}

public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.println("Enter the username:");
String name = sc.nextLine();  
}
}

    

