/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompanydaretodream.user_application;

/**
 *
 * @author Swiki
 */
import java.util.Scanner;
public class User_Application {

    public static void main(String[] args) 
    {
       String username,password;
       Scanner s = new Scanner(System.in);
        System.out.println("Enter username:Swiki");
        username = s.nextLine();
        System.out.println("welcome<Swiki<nekhaguma>it is good to see you again");
        System.out.println("Enter password:123abc@A");
        password = s.nextLine();
        System.out.println("password succefully completed");
        if(username.equals("Swiki") && password.equals("Swiki"))
        {
            System.out.println("Authentication successful");
        } 
        else
            System.out.println("Authentication Failed");
    }
}
